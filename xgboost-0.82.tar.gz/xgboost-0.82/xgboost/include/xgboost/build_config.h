/*!
 * Copyright 2019 by Contributors
 * \file build_config.h
 */
#ifndef XGBOOST_BUILD_CONFIG_H_
#define XGBOOST_BUILD_CONFIG_H_

#define XGBOOST_MM_PREFETCH_PRESENT
#define XGBOOST_BUILTIN_PREFETCH_PRESENT

#endif  // XGBOOST_BUILD_CONFIG_H_
