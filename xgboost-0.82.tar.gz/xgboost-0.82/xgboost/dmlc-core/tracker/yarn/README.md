DMLC YARN AppMaster
===================
* This folder contains Application code to allow rabit run on Yarn.
* See [tracker](../) for job submission.
  - run ```./build.sh``` to build the jar, before using the script
