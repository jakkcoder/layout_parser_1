from statsmodels import NoseWrapper as Tester
test = Tester().test

from .formulatools import handle_formula_data
