from var_plots import plot_fevd
plot_fevd()
