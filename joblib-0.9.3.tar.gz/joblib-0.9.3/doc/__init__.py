"""
This is a phony __init__.py file, so that nose finds the doctests in this
directory.
"""
