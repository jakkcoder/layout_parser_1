joblib.hashing.hash
===================

.. currentmodule:: joblib.hashing

.. autofunction:: hash