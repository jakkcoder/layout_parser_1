joblib.dump
===========

.. currentmodule:: joblib

.. autofunction:: dump