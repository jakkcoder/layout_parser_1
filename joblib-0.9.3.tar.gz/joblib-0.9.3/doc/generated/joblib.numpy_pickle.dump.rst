joblib.numpy_pickle.dump
========================

.. currentmodule:: joblib.numpy_pickle

.. autofunction:: dump