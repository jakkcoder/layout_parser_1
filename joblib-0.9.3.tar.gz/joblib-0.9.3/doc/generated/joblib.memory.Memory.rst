joblib.memory.Memory
====================

.. currentmodule:: joblib.memory

.. autoclass:: Memory

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Memory.__init__
      ~Memory.cache
      ~Memory.clear
      ~Memory.debug
      ~Memory.eval
      ~Memory.format
      ~Memory.warn
   
   

   
   
   