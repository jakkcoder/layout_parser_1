joblib.numpy_pickle.load
========================

.. currentmodule:: joblib.numpy_pickle

.. autofunction:: load