joblib.parallel.Parallel
========================

.. currentmodule:: joblib.parallel

.. autoclass:: Parallel

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Parallel.__init__
      ~Parallel.debug
      ~Parallel.dispatch
      ~Parallel.dispatch_next
      ~Parallel.format
      ~Parallel.print_progress
      ~Parallel.retrieve
      ~Parallel.warn
   
   

   
   
   