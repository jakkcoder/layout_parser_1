.. _multioutput_examples:

Multioutput methods
-------------------

Examples concerning the :mod:`sklearn.multioutput` module.
