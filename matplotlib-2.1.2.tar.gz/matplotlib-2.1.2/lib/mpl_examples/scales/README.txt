.. _scales_examples:

Scales in Matplotlib
====================

These examples cover how different scales are handled in Matplotlib.
